const o="";export{o as template};
//# sourceMappingURL=_virtual_spa-template.mjs.map
